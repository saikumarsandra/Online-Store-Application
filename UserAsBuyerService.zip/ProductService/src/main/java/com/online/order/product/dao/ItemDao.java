package com.online.order.product.dao;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.online.order.product.model.Item;

@Repository
public interface ItemDao extends JpaRepository<Item, Integer> {
	

	@Query(value = "SELECT * FROM Item item WHERE item.sellerId = :sellerId"	,nativeQuery = true)
	List<Item> getAllItemsBysellerid(@Param("sellerId")Integer sellerId);
	
	@Query(value="SELECT * FROM Item item WHERE lower(item.itemName) LIKE %:itemname%",nativeQuery = true)
	  List<Item> getAllByitemName(@Param("itemname") String itemname);
	
	
	@Query(value="SELECT * FROM Item item WHERE item.subcategoryid= :subcategoryid",nativeQuery=true)
	List<Item> getBysubcatogoryType(@Param("subcategoryid") int subcategoryid);
	
	@Query(value="SELECT * FROM Item ",nativeQuery=true)
	List<Item> getAllItem();
	
}

