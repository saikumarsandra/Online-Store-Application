package com.online.order.product.service;

import java.util.List;



import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.online.order.product.dao.ItemDao;
import com.online.order.product.dao.SellerDao;
import com.online.order.product.model.Item;


@Service
public class ItemSeriveImplementation implements ItemSerivce  {

	@Autowired
	ItemDao itemdao;
	
	@Autowired
	SellerDao sellerdao;
	
	
	@Override
	public Optional<Item> addItem(Item item,Integer sellerid) {
		
		return  sellerdao.findById(sellerid).map(seller ->{
			item.setSeller(seller);
			
			return itemdao.save(item);
		});
		
	}

	@Override
	public Item updateItem(Item item, Integer id) {
		
		Optional<Item> itemobject=itemdao.findById(id);
		Item item1=null;
		if(itemobject.isPresent())
		{
			item1= itemobject.get();
			item1.setItemDescription(item.getItemDescription());
			item1.setItemCost(item.getItemCost());
			item.setManufacturer(item.getManufacturer());
			item1.setQuantity(item.getQuantity());
			item1.setStock(item.getStock());
			
			return    itemdao.save(item1);
			
		}
		return item1;
	
	}

	@Override
	public List<Item> getAllBysellerid(Integer id) {


		return itemdao.getAllItemsBysellerid(id);
		}

	@Override
	public Item getbyid(Integer id) {
		
		Optional<Item> item = itemdao.findById(id);
		 return item.isPresent() ? item.get(): null;
	
	}
	@Override
	public List<Item> getAllByitemName(String itemname) {
		
		return itemdao.getAllByitemName(itemname.toLowerCase());
	}

	@Override
	public void deleteItem(Integer id) {
	Optional<Item> itemid = itemdao.findById(id);
		
		if(itemid.isPresent())
		{
			itemdao.deleteById(id);
		}
		
	}

	@Override
	public List<Item> getBysubcategoryid(Integer id) {
		
		return itemdao.getBysubcatogoryType(id);
	}

	@Override
	public List<Item> getAllItems() {
		
		return itemdao.getAllItem();
	}

}
