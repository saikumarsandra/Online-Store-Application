package com.online.order.product.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.online.order.product.model.SellerEntity;

@Repository
public interface SellerDao extends JpaRepository<SellerEntity,Integer> {

	SellerEntity findByusername(String username);
}
