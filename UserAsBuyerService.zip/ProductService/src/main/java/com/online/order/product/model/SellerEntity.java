package com.online.order.product.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;

import javassist.SerialVersionUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="seller")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor


public class SellerEntity  implements Serializable  {
	
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int sellerid;
	@Column
	private String username;
	private String password;
	private String companyname;
	private Double gstin;
	private String briefaboutcompany;
	private String website;
	private String emailId;
	private String contactnumber;
	private String postaladdress;
	
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	private Date CreatedDate;
	
	public SellerEntity(int sellerid, String username, String password, String companyname, Double gstin,
			String briefaboutcompany, String website, String emailId, String contactnumber, String postaladdress) {
		super();
		this.sellerid = sellerid;
		this.username = username;
		this.password = password;
		this.companyname = companyname;
		this.gstin = gstin;
		this.briefaboutcompany = briefaboutcompany;
		this.website = website;
		this.emailId = emailId;
		this.contactnumber = contactnumber;
		this.postaladdress = postaladdress;
	}
	

}
