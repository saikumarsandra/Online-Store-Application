package com.online.order.product.model;

import java.io.Serializable;


import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;

import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


//import com.cts.entity.CategoryEntity;

@Entity
@Table(name="item")


public class Item implements Serializable {
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	 private int itemid;
	 private int categoryid;
	 private int subcategoryid;
	// @Column
	 private Double  itemCost;
	 private String itemName;
	 private String itemDescription;
	 private int quantity;
	 private String model;
	 private String manufacturer;
	 private String stock;
	 
	
	public int getItemid() {
		return itemid;
	}


	public void setItemid(int itemid) {
		this.itemid = itemid;
	}


	public int getCategoryid() {
		return categoryid;
	}


	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}


	public int getSubcategoryid() {
		return subcategoryid;
	}


	public void setSubcategoryid(int subcategoryid) {
		this.subcategoryid = subcategoryid;
	}


	public Double getItemCost() {
		return itemCost;
	}


	public void setItemCost(Double itemCost) {
		this.itemCost = itemCost;
	}


	public String getItemName() {
		return itemName;
	}


	public void setItemName(String itemName) {
		this.itemName = itemName;
	}


	public String getItemDescription() {
		return itemDescription;
	}


	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public String getModel() {
		return model;
	}


	public void setModel(String model) {
		this.model = model;
	}


	public String getManufacturer() {
		return manufacturer;
	}


	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}


	public String getStock() {
		return stock;
	}


	public void setStock(String stock) {
		this.stock = stock;
	}


	public SellerEntity getSeller() {
		return seller;
	}


	public void setSeller(SellerEntity seller) {
		this.seller = seller;
	}


	public Item(int itemid, int categoryid, int subcategoryid, Double itemCost, String itemName, String itemDescription,
			int quantity, String model, String manufacturer, String stock, SellerEntity seller) {
		super();
		this.itemid = itemid;
		this.categoryid = categoryid;
		this.subcategoryid = subcategoryid;
		this.itemCost = itemCost;
		this.itemName = itemName;
		this.itemDescription = itemDescription;
		this.quantity = quantity;
		this.model = model;
		this.manufacturer = manufacturer;
		this.stock = stock;
		this.seller = seller;
	}


	@Override
	public String toString() {
		return "Item [itemid=" + itemid + ", categoryid=" + categoryid + ", subcategoryid=" + subcategoryid
				+ ", itemCost=" + itemCost + ", itemName=" + itemName + ", itemDescription=" + itemDescription
				+ ", quantity=" + quantity + ", model=" + model + ", manufacturer=" + manufacturer + ", stock=" + stock
				+ ", seller=" + seller + "]";
	}


	public Item() {
	
	}


	@ManyToOne /* (fetch = FetchType.LAZY, optional = false) */
	    @JoinColumn(name = "sellerId", nullable = false)
	    @OnDelete(action = OnDeleteAction.CASCADE)
	 private SellerEntity  seller;
	 
	 
		
}
