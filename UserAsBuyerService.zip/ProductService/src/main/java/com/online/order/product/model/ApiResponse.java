package com.online.order.product.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
@RequiredArgsConstructor


public class ApiResponse<T> {

    private int status;
    private String message;
    private Object result;

  
    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getResult() {
        this.status = status;
        this.message = message;
        this.result = result;
    
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }
}
