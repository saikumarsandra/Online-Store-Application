package com.user.as.buyer.service;

import java.util.List;
import java.util.Optional;



import com.user.as.buyer.model.BuyerEntity;


public interface IBuyerService {
	
	
	BuyerEntity createBuyer(BuyerEntity buyer);
	BuyerEntity  updateBuyer(Integer buyerId,BuyerEntity buyer);
	void  deleteById(Integer buyerId );
	public Optional<BuyerEntity> findById(Integer buyerId);
      BuyerEntity findOne(String username);
      List<BuyerEntity> getAllBuyers();
 	 

}
