package com.user.as.buyer.model;

import java.util.Date;



public class OrderModel {
	
private 	Integer id;
private String itemName;
private double price;
private Integer numberOfItems;
private Integer orderId;
private Date createdOn;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getItemName() {
	return itemName;
}
public void setItemName(String itemName) {
	this.itemName = itemName;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public Integer getNumberOfItems() {
	return numberOfItems;
}
public void setNumberOfItems(Integer numberOfItems) {
	this.numberOfItems = numberOfItems;
}
public Integer getOrderId() {
	return orderId;
}
public void setOrderId(Integer orderId) {
	this.orderId = orderId;
}
public Date getCreatedOn() {
	return createdOn;
}
public void setCreatedOn(Date createdOn) {
	this.createdOn = createdOn;
}
public OrderModel(Integer id, String itemName, double price, Integer numberOfItems, Integer orderId, Date createdOn) {
	super();
	this.id = id;
	this.itemName = itemName;
	this.price = price;
	this.numberOfItems = numberOfItems;
	this.orderId = orderId;
	this.createdOn = createdOn;
}
public OrderModel() {
	
}
@Override
public String toString() {
	return "OrderModel [id=" + id + ", itemName=" + itemName + ", price=" + price + ", numberOfItems=" + numberOfItems
			+ ", orderId=" + orderId + ", createdOn=" + createdOn + "]";
}



}
