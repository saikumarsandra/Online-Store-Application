package com.user.as.buyer.service;

import java.util.Optional;




import com.user.as.buyer.model.TransactionEntity;


public interface ITranscation {
	
	
    TransactionEntity   createTransaction(int id,TransactionEntity transaction);
	
	
	

}
