package com.user.as.buyer.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.user.as.buyer.model.PurchaseHistory;


@Repository
public interface PurchaseDao  extends JpaRepository<PurchaseHistory, Integer> {

	
	@Query(value = "SELECT * FROM purchasehistory p WHERE p.buyer_id = :buyerId",nativeQuery = true)
	List<PurchaseHistory> getOrderDetails(@Param("buyerId")Integer buyerId);

	
}
