package com.user.as.buyer.model;

import java.util.List;

public class ListOfOrders {
	
	List<PurchaseHistory> newsFeeds;

	public List<PurchaseHistory> getNewsFeeds() {
		return newsFeeds;
	}

	public void setNewsFeeds(List<PurchaseHistory> newsFeeds) {
		this.newsFeeds = newsFeeds;
	}
	}


