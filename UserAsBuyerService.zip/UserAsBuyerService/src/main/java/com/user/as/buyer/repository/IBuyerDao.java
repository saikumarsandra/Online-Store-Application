package com.user.as.buyer.repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import com.user.as.buyer.model.BuyerEntity;


@Repository
public interface IBuyerDao extends JpaRepository<BuyerEntity, Integer>  {

	
	BuyerEntity findByuserName(String username);
	
	
	
	

	
}
