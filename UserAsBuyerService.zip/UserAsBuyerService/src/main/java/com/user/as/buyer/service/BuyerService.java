package com.user.as.buyer.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.user.as.buyer.exception.ResourceNotFoundException;
import com.user.as.buyer.model.BuyerEntity;
import com.user.as.buyer.repository.IBuyerDao;


@Service(value = "userService")
public class BuyerService implements IBuyerService,UserDetailsService {
	
	@Autowired
	private IBuyerDao buyerdao;
	

	  @Autowired
		private BCryptPasswordEncoder bcryptEncoder;

		public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
			BuyerEntity buyer = buyerdao.findByuserName(username);
			if(buyer == null){
				throw new UsernameNotFoundException("Invalid username or password.");
			}
			return new org.springframework.security.core.userdetails.User(buyer.getUserName(), buyer.getPassword(), getAuthority());
		}

		private List<SimpleGrantedAuthority> getAuthority() {
			return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
		}

		
		@Override
		public BuyerEntity createBuyer(BuyerEntity buyer) {
			 buyer.setPassword(bcryptEncoder.encode(buyer.getPassword()));
           
			return buyerdao.save(buyer);
		}


	@Override
	public BuyerEntity updateBuyer(Integer buyerId,BuyerEntity buyer) {

		Optional<BuyerEntity> buyerobject = buyerdao.findById(buyer.getBuyerId());
		
		BuyerEntity buyer1 = null;
		if(buyerobject.isPresent()) {
			buyer1 = buyerobject.get();
			buyer1.setUserName(buyer.getUserName());
			buyer1.setEmail(buyer.getEmail());
			buyer1.setMobileNumber(buyer.getMobileNumber());
			buyer1.setPassword(bcryptEncoder.encode(buyer.getPassword()));
			 buyer1= buyerdao.save(buyer1);
		}
		return buyer1;
	
	}

	@Override
	public void deleteById(Integer buyerId) {
		Optional<BuyerEntity> buyerid = buyerdao.findById(buyerId);
		
		if(buyerid.isPresent())
		{
			buyerdao.deleteById(buyerId);
		}
		
		
	}


	@Override
	public Optional<BuyerEntity> findById(Integer buyerId) {
		
		return this.buyerdao.findById(buyerId);
	}


	@Override
	public BuyerEntity findOne(String username) {
		
		
		return buyerdao.findByuserName(username);
	}

	@Override
	public List<BuyerEntity> getAllBuyers() {
		
		List<BuyerEntity> users=this.buyerdao.findAll();

		return users;
	}
	

	
	
}
