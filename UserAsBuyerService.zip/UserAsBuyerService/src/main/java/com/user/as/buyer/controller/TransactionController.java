package com.user.as.buyer.controller;

import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.user.as.buyer.model.TransactionEntity;
import com.user.as.buyer.service.TransactionImplementation;

//import com.cts.Entity.TransactionEntity;
//import com.cts.Service.TransactionImplementation;
@CrossOrigin("*")
@RestController
public class TransactionController {
	
	@Autowired
	private TransactionImplementation transactionservice;
	
	  
	  @PostMapping("/Buyer/{buyerId}/Transaction")
	  public TransactionEntity createTransaction(@PathVariable (value = "buyerId") int buyerid,
              @Valid @RequestBody TransactionEntity transaction )
	  {
		  
		  return transactionservice.createTransaction(buyerid, transaction);
	  }

	
	
	
	

}
