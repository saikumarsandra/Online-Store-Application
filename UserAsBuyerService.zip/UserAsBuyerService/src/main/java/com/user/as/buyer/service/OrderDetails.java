package com.user.as.buyer.service;

import java.util.List;

import com.user.as.buyer.model.PurchaseHistory;

public interface OrderDetails {
	
	List<PurchaseHistory> getOrderDetails(Integer BuyerId);

}
