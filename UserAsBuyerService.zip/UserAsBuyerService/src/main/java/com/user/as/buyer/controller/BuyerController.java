package com.user.as.buyer.controller;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.user.as.buyer.model.ApiResponse;
import com.user.as.buyer.model.BuyerEntity;
import com.user.as.buyer.model.BuyerList;
import com.user.as.buyer.service.BuyerService;

@CrossOrigin("*")
@RestController
public class BuyerController {
	
	@Autowired
	private BuyerService buyerservice;
	
	
	
	  @GetMapping("/Buyers")
	  public ResponseEntity<BuyerList> getUserDetails(){
			List<BuyerEntity> details=this.buyerservice.getAllBuyers();
			if(details == null)
				throw new UsernameNotFoundException("Not able to fetch records!!!");
			BuyerList userData=new BuyerList();
			userData.setData(details);
			ResponseEntity<BuyerList> response=new ResponseEntity<BuyerList>(userData, HttpStatus.OK);
			return response;
		}
	
	@GetMapping("/Buyer/{id}")
	public Optional<BuyerEntity> getByOwnerId(@PathVariable ("id") Integer buyerId)
	{
	
	return  this.buyerservice.findById(buyerId);
}
	  @PostMapping("/Buyer")
	    public BuyerEntity createBuyer( @RequestBody BuyerEntity buyer) {
	      System.out.println("buyer  recived");
	      
		  return buyerservice.createBuyer(buyer);
	    }

	    @PutMapping("/update/{buyerId}")
	    public BuyerEntity updateBuyer(@PathVariable Integer  buyerId,@RequestBody BuyerEntity buyer) {
	        return buyerservice.updateBuyer(buyerId, buyer);	        
	    }

	 
	    
	    
	
	  @DeleteMapping("/delete/{id}") 
	  public void deleteById(@PathVariable("id") int buyerId) {
		 
	        buyerservice.deleteById(buyerId);
	
	
	  }
	  
	
}
