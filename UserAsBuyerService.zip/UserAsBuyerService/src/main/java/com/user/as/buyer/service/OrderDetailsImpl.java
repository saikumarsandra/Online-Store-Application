package com.user.as.buyer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.as.buyer.model.PurchaseHistory;
import com.user.as.buyer.repository.PurchaseDao;

@Service
public class OrderDetailsImpl implements OrderDetails {

	@Autowired
	public PurchaseDao order;
	@Override
	public List<PurchaseHistory> getOrderDetails(Integer BuyerId) {
		
		return order.getOrderDetails(BuyerId);
	}

}
