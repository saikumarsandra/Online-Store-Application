package com.user.as.buyer.service;

import java.util.List;

import java.util.Optional;

import com.user.as.buyer.model.BuyerEntity;
import com.user.as.buyer.model.ShoppingCart;
import com.user.as.buyer.model.TransactionEntity;
import com.user.as.buyer.repository.ShoppingCartDao;
import com.user.as.buyer.response.CartResponse;

public interface IShoppingCartService {

	void DeleteItemIncart(Integer carditemId);
	ShoppingCart UpdateCart(ShoppingCart shoppingcartitem,Integer CaritemtId);
	TransactionEntity CheckoutCart(Integer buyerid,TransactionEntity transactionhistory);
	Optional<ShoppingCart> addItemToCart(Integer buyerId,ShoppingCart shoppincart);
	List<ShoppingCart> getAllCart(Integer BuyerId);
	void emptyCart(Integer buyerId);
	CartResponse updateItemqunatity(CartResponse cart);
}
