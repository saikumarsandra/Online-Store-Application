package com.user.as.buyer.service;

import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.user.as.buyer.exception.ResourceNotFoundException;
import com.user.as.buyer.model.TransactionEntity;
import com.user.as.buyer.repository.IBuyerDao;
import com.user.as.buyer.repository.ITransactionDao;
import com.user.as.buyer.repository.PurchaseDao;



@Service
public class TransactionImplementation implements ITranscation {

	@Autowired
	private ITransactionDao transactiondao;
	
	@Autowired
	private IBuyerDao buyerdao;
	
   @Autowired
	private  PurchaseDao order;
	
	@Override
	public TransactionEntity createTransaction(int id,TransactionEntity transaction) {
		
		
		
		
		return buyerdao.findById(id).map(buyerentity -> {
			transaction.setBuyerentity(buyerentity);
		   
            return transactiondao.save(transaction);
           
        }).orElseThrow(() -> new ResourceNotFoundException("PostId " + id + " not found"));
	}

	
}
