package com.user.as.buyer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.user.as.buyer.model.PurchaseHistory;

import com.user.as.buyer.service.OrderDetailsImpl;
@CrossOrigin("*")
@RestController
public class OrederDetailsController {
	@Autowired
	public OrderDetailsImpl orderService;
	
	@GetMapping("/{buyerid}/getall")
	public List<PurchaseHistory> getOrderDetails(@PathVariable("buyerid") Integer id)
	{
		return orderService.getOrderDetails(id);
	}

}
