package com.user.as.buyer.model;

import java.util.List;

public class BuyerList {
	
	
	List<BuyerEntity> data;

	public List<BuyerEntity> getData() {
		return data;
	}

	public void setData(List<BuyerEntity> data) {
		this.data = data;
	}

}
