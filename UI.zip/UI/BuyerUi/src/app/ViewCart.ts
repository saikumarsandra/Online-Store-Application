export class ViewCart
{
     cartId: number;
	 itemId:number;
	 noOfItems:number;
	 price:number;
	 
	 
	
}