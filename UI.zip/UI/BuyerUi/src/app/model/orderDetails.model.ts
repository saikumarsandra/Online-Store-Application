export class PurchaseHistory{

  
          purchaseId:number;
        itemId: number;
        itemName: string;
        orderId: string;
        numberOfItems: number;
        price: number;
        buyerId:number;
 
}