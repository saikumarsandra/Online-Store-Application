export class Buyer
{
    buyerId:number;
userName:string;
password:string;
email:string;
mobileNumber:number;
address:string;

}