export class TransactionEntity1
{
    
    
    transactionId:number;
    orderId:string;
    transactionType:string;
    totalamount:number;
    itemName:string;
}

export class TransactionEntity
{
    
    transactionId:number;
    totalamount:number;
    orderId:string;
    transactionType:string;
    itemName:string;
}